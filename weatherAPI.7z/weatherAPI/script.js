document.addEventListener("DOMContentLoaded", () => {
  const cityInput = document.getElementById("city-input");
  const getWeatherBtn = document.getElementById("get-weather-btn");
  const weatherInfo = document.getElementById("weather-info");
  const errorMsg = document.getElementById("error-message");

  const apiKey = "VWCVJQNGLUBVJJLK6BKDTH7BZ";

  getWeatherBtn.addEventListener("click", async () => {
    const cityName = cityInput.value.trim();
    if (!cityName) {
      showError();
      return;
    }

    const response = await fetchData(cityName);
    console.log(response);
  });

  async function fetchData(city) {
    const cityname = city;
    try {
      const response = await fetch(
        `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/[cityname]?key=apiKey
`
      );

      return response;
    } catch (error) {}
  }

  function displayData(data) {}

  function showError() {
    weatherInfo.classList.add("hidden");
    errorMsg.classList.remove("hidden");
  }
});
